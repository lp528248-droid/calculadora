// Calculadora simples em JavaScript puro (sem eval).
// Estado: número atual, número anterior e operador escolhido.

const MAX_DIGITOS = 12;
const SIMBOLOS = { "+": "+", "-": "−", "*": "×", "/": "÷" };

let atual = "0";
let anterior = null;
let operador = null;
let novoNumero = true; // true = o próximo dígito começa um número novo

const elResultado = document.getElementById("resultado");
const elExpressao = document.getElementById("expressao");

function formatar(texto) {
  return texto.replace(".", ",");
}

function atualizarVisor() {
  elResultado.classList.remove("erro");
  elResultado.textContent = formatar(atual);
  elExpressao.textContent =
    operador !== null ? `${formatar(String(anterior))} ${SIMBOLOS[operador]}` : "";

  document.querySelectorAll(".operador").forEach((botao) => {
    botao.classList.toggle("ativo", botao.dataset.operador === operador && novoNumero);
  });
}

function mostrarErro(mensagem) {
  atual = "0";
  anterior = null;
  operador = null;
  novoNumero = true;
  elResultado.textContent = mensagem;
  elResultado.classList.add("erro");
  elExpressao.textContent = "";
}

function digitar(numero) {
  if (novoNumero) {
    atual = numero;
    novoNumero = false;
  } else if (atual.replace(/[-.]/g, "").length < MAX_DIGITOS) {
    atual = atual === "0" ? numero : atual + numero;
  }
  atualizarVisor();
}

function decimal() {
  if (novoNumero) {
    atual = "0.";
    novoNumero = false;
  } else if (!atual.includes(".")) {
    atual += ".";
  }
  atualizarVisor();
}

function escolherOperador(novoOperador) {
  // Se já havia uma operação pendente, calcula antes (ex.: 2 + 3 + ...)
  if (operador !== null && !novoNumero) {
    if (!calcular()) return;
  }
  anterior = parseFloat(atual);
  operador = novoOperador;
  novoNumero = true;
  atualizarVisor();
}

function calcular() {
  if (operador === null) return true;

  const a = anterior;
  const b = parseFloat(atual);
  let resultado;

  switch (operador) {
    case "+": resultado = a + b; break;
    case "-": resultado = a - b; break;
    case "*": resultado = a * b; break;
    case "/":
      if (b === 0) {
        mostrarErro("Não é possível dividir por zero");
        return false;
      }
      resultado = a / b;
      break;
  }

  // Evita erros de ponto flutuante (0.1 + 0.2 = 0.30000000000000004)
  resultado = parseFloat(resultado.toPrecision(12));

  atual = String(resultado);
  anterior = null;
  operador = null;
  novoNumero = true;
  atualizarVisor();
  return true;
}

function limpar() {
  atual = "0";
  anterior = null;
  operador = null;
  novoNumero = true;
  atualizarVisor();
}

function apagar() {
  if (novoNumero) return;
  atual = atual.length > 1 && !(atual.length === 2 && atual[0] === "-")
    ? atual.slice(0, -1)
    : "0";
  atualizarVisor();
}

function inverterSinal() {
  if (atual === "0") return;
  atual = atual.startsWith("-") ? atual.slice(1) : "-" + atual;
  atualizarVisor();
}

function porcentagem() {
  atual = String(parseFloat((parseFloat(atual) / 100).toPrecision(12)));
  novoNumero = true;
  atualizarVisor();
}

const acoes = { limpar, apagar, decimal, inverter: inverterSinal, porcentagem, igual: calcular };

// Cliques nos botões
document.querySelector(".teclas").addEventListener("click", (evento) => {
  const botao = evento.target.closest("button");
  if (!botao) return;

  if (botao.dataset.numero) digitar(botao.dataset.numero);
  else if (botao.dataset.operador) escolherOperador(botao.dataset.operador);
  else if (botao.dataset.acao) acoes[botao.dataset.acao]();
});

// Suporte ao teclado
document.addEventListener("keydown", (evento) => {
  const tecla = evento.key;

  if (/^[0-9]$/.test(tecla)) digitar(tecla);
  else if (["+", "-", "*", "/"].includes(tecla)) escolherOperador(tecla);
  else if (tecla === "," || tecla === ".") decimal();
  else if (tecla === "Enter" || tecla === "=") {
    evento.preventDefault();
    calcular();
  }
  else if (tecla === "Backspace") apagar();
  else if (tecla === "Escape") limpar();
  else if (tecla === "%") porcentagem();
});

atualizarVisor();
