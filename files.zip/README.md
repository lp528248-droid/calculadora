# Calculadora

Calculadora web feita com **HTML, CSS e JavaScript puro**, sem bibliotecas.

## Funcionalidades

- Soma, subtração, multiplicação e divisão
- Porcentagem, inverter sinal (±) e números decimais
- Botões **C** (limpar tudo) e **⌫** (apagar último dígito)
- Encadeamento de operações (ex.: `2 + 3 × 4`, calculado na ordem digitada)
- Tratamento de divisão por zero
- Correção de erros de ponto flutuante (`0,1 + 0,2 = 0,3`)
- Suporte ao teclado: números, `+ - * /`, `Enter`, `Backspace` e `Esc`
- Layout responsivo e acessível (foco visível e `aria-label` nos botões)

## Como executar

1. Baixe ou clone este repositório
2. Abra o arquivo `index.html` no navegador

```bash
git clone https://github.com/SEU-USUARIO/calculadora.git
```

## Estrutura

```
calculadora/
├── index.html   # estrutura da página
├── style.css    # estilos
└── script.js    # lógica da calculadora
```

## O que pratiquei neste projeto

- Manipulação do DOM e eventos (`click` e `keydown`)
- Lógica de programação: variáveis de estado, `switch`, funções e condicionais
- Tratamento de casos de erro
- CSS com variáveis, Grid e responsividade

## Autor

Luan Pereira Gonzaga — [LinkedIn](https://www.linkedin.com/in/luanpereira-dev)
